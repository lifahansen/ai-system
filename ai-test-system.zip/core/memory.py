import json
import os

class Memory:

    def __init__(self, path="data/history.json"):
        self.path = path
        os.makedirs("data", exist_ok=True)
        if not os.path.exists(path):
            with open(path, "w") as f:
                json.dump({}, f)

    def load(self):
        with open(self.path, "r") as f:
            return json.load(f)

    def update(self, strategy):
        data = self.load()

        for k, v in strategy.get("adjust_priority", {}).items():
            data[k] = data.get(k, 1) + v

        with open(self.path, "w") as f:
            json.dump(data, f, indent=2)
