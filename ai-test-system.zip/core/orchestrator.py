from agents.test_case_agent import TestCaseAgent
from agents.execution_agent import ExecutionAgent
from agents.analysis_agent import AnalysisAgent
from agents.optimization_agent import OptimizationAgent
from core.memory import Memory

class Orchestrator:

    def __init__(self):
        self.memory = Memory()
        self.test_agent = TestCaseAgent(self.memory)
        self.exec_agent = ExecutionAgent()
        self.analysis_agent = AnalysisAgent()
        self.opt_agent = OptimizationAgent(self.memory)

    def run(self, requirement: str):

        cases = self.test_agent.generate(requirement)
        results = self.exec_agent.execute(cases)
        analysis = self.analysis_agent.analyze(results)
        strategy = self.opt_agent.optimize(analysis)
        self.memory.update(strategy)

        return {
            "cases": cases,
            "results": results,
            "analysis": analysis,
            "strategy": strategy
        }
