class OptimizationAgent:

    def __init__(self, memory):
        self.memory = memory

    def optimize(self, analysis):

        strategy = {
            "adjust_priority": {},
            "new_cases": []
        }

        for a in analysis:
            name = a["name"]

            strategy["adjust_priority"][name] = 1

            if a["type"] == "logic":
                strategy["new_cases"].append(f"{name}_空值测试")

        return strategy
