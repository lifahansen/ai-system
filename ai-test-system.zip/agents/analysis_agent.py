class AnalysisAgent:

    def analyze(self, results):

        analysis = []

        for r in results:
            if r["result"] == "fail":
                analysis.append({
                    "case_id": r["case_id"],
                    "name": r["name"],
                    "reason": "可能为空值未处理",
                    "type": "logic"
                })

        return analysis
