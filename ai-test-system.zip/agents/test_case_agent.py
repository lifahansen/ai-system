import uuid

class TestCaseAgent:

    def __init__(self, memory):
        self.memory = memory

    def generate(self, requirement: str):

        history = self.memory.load()

        base_cases = [
            "正常流程",
            "异常输入",
            "边界条件"
        ]

        cases = []
        for name in base_cases:
            priority = history.get(name, 1)

            cases.append({
                "id": str(uuid.uuid4()),
                "name": name,
                "steps": f"测试 {name}",
                "expected": "成功",
                "priority": priority
            })

        return sorted(cases, key=lambda x: -x["priority"])
