import random

class ExecutionAgent:

    def execute(self, cases):
        results = []

        for case in cases:
            res = random.choices(
                ["pass", "fail"],
                weights=[0.7, 0.3]
            )[0]

            results.append({
                "case_id": case["id"],
                "name": case["name"],
                "result": res,
                "log": "mock log"
            })

        return results
